window.Utils = {
  fmtDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: '2-digit' });
  },
  fmtDateTime(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleString(undefined, {
      year: 'numeric', month: 'short', day: '2-digit',
      hour: '2-digit', minute: '2-digit'
    });
  },
  initials(name = '') {
    return name.split(' ').filter(Boolean).slice(0, 2).map(p => p[0].toUpperCase()).join('');
  },
  statusClass(s) {
    const map = {
      'New': 'badge-new',
      'Under Review': 'badge-review',
      'Assigned': 'badge-assigned',
      'In Progress': 'badge-progress',
      'Resolved': 'badge-resolved',
      'Closed': 'badge-closed'
    };
    return map[s] || 'badge-new';
  },
  priorityClass(p) {
    return 'badge-priority-' + (p || 'low').toLowerCase();
  },
  qs(name) {
    return new URLSearchParams(location.search).get(name);
  },
  esc(str = '') {
    return String(str).replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }
};