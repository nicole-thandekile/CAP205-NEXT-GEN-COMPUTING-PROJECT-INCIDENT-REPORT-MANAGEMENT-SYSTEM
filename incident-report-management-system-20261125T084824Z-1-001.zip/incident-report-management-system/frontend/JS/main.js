// Generic helpers used across pages
window.App = {
  showAlert(elOrId, message, type = 'info') {
    const el = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
    if (!el) return;
    el.className = `alert alert-${type} show`;
    el.textContent = message;
    setTimeout(() => el.classList.remove('show'), 4000);
  }
};