document.addEventListener('layout:ready', () => {
  if (!Auth.requireAuth()) return;

  const form = document.getElementById('incidentForm');
  if (!form) return;

  // Populate category dropdown
  const catSel = form.querySelector('[name="category"]');
  if (catSel) {
    catSel.innerHTML = `<option value="">-- Select category --</option>` +
      MOCK.categories.map(c => `<option value="${c}">${c}</option>`).join('');
  }
  const priSel = form.querySelector('[name="priority"]');
  if (priSel) {
    priSel.innerHTML = `<option value="">-- Select priority --</option>` +
      MOCK.priorities.map(p => `<option value="${p}">${p}</option>`).join('');
  }

  // Pre-fill date
  const dateInput = form.querySelector('[name="incidentDate"]');
  if (dateInput && !dateInput.value) dateInput.value = new Date().toISOString().slice(0, 10);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!Validate.required(form)) return;

    const data = Object.fromEntries(new FormData(form).entries());
    const fileInput = form.querySelector('[name="evidenceFile"]');
    if (fileInput && fileInput.files[0]) data.evidence = fileInput.files[0].name;

    const created = await API.createIncident(data);
    App.showAlert('formAlert', `Report #${created.id} submitted successfully.`, 'success');
    form.reset();
    setTimeout(() => location.href = `incident-details.html?id=${created.id}`, 1200);
  });
});