// Track & Analyze page — computes live summary numbers from incident data.
document.addEventListener('layout:ready', async () => {
  const ids = ['taTotal', 'taOpen', 'taResolved', 'taCritical'];
  const setText = (id, v) => {
    const el = document.getElementById(id);
    if (el) el.textContent = v;
  };

  const list = await API.getIncidents();
  if (!Array.isArray(list)) return;

  const total = list.length;
  if (!total) {
    ids.forEach(id => setText(id, 0));
    const empty = document.getElementById('taCategoryBars');
    if (empty) empty.innerHTML = '<p class="text-muted">No incident data yet.</p>';
    return;
  }

  // Overview stats
  const open = list.filter(i => !['Resolved', 'Closed'].includes(i.status)).length;
  const resolved = list.filter(i => ['Resolved', 'Closed'].includes(i.status)).length;
  const critical = list.filter(i => i.priority === 'Critical').length;
  setText('taTotal', total);
  setText('taOpen', open);
  setText('taResolved', resolved);
  setText('taCritical', critical);

  // Per-status counts
  const byStatus = list.reduce((acc, i) => {
    acc[i.status] = (acc[i.status] || 0) + 1;
    return acc;
  }, {});
  document.querySelectorAll('[data-status-count]').forEach(el => {
    el.textContent = byStatus[el.dataset.statusCount] || 0;
  });

  // Per-priority counts
  const byPriority = list.reduce((acc, i) => {
    acc[i.priority] = (acc[i.priority] || 0) + 1;
    return acc;
  }, {});
  document.querySelectorAll('[data-priority-count]').forEach(el => {
    el.textContent = byPriority[el.dataset.priorityCount] || 0;
  });

  // Incidents by category (horizontal bars)
  const byCategory = list.reduce((acc, i) => {
    acc[i.category] = (acc[i.category] || 0) + 1;
    return acc;
  }, {});
  const rows = Object.entries(byCategory)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const bars = document.getElementById('taCategoryBars');
  if (bars) {
    const inner = rows.length
      ? rows.map(([cat, n]) => `
        <div class="bar-row">
          <span class="bar-label">${Utils.esc(cat)}</span>
          <div class="bar-track">
            <div class="bar-fill" style="width:${Math.round(n / total * 100)}%"></div>
          </div>
          <span class="bar-count">${n}</span>
        </div>`).join('')
      : '<p class="text-muted">No incident data yet.</p>';
    bars.innerHTML = inner;
  }
});