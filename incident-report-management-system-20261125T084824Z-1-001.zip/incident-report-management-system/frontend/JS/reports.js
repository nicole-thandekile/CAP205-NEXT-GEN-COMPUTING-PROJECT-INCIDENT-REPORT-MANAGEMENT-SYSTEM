document.addEventListener('layout:ready', async () => {
  if (!Auth.requireAuth()) return;

  const list = await API.getIncidents();
  const total = list.length;

  // By status
  const byStatus = {};
  MOCK.statuses.forEach(s => byStatus[s] = 0);
  list.forEach(i => byStatus[i.status] = (byStatus[i.status] || 0) + 1);

  document.getElementById('statusBars').innerHTML = MOCK.statuses.map(s => {
    const c = byStatus[s];
    const pct = total ? Math.round((c / total) * 100) : 0;
    return `<div class="bar-row">
      <span>${s}</span>
      <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
      <span class="bar-count">${c}</span>
    </div>`;
  }).join('');

  // By category
  const byCat = {};
  list.forEach(i => byCat[i.category] = (byCat[i.category] || 0) + 1);
  const maxCat = Math.max(1, ...Object.values(byCat));
  document.getElementById('categoryBars').innerHTML =
    Object.entries(byCat).sort((a,b) => b[1]-a[1]).map(([c, n]) => {
      const pct = Math.round((n / maxCat) * 100);
      return `<div class="bar-row">
        <span>${Utils.esc(c)}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
        <span class="bar-count">${n}</span>
      </div>`;
    }).join('') || '<p class="text-muted">No data.</p>';

  // By priority
  const byPri = {};
  MOCK.priorities.forEach(p => byPri[p] = 0);
  list.forEach(i => byPri[i.priority] = (byPri[i.priority] || 0) + 1);
  document.getElementById('priorityBars').innerHTML = MOCK.priorities.map(p => {
    const c = byPri[p];
    const pct = total ? Math.round((c / total) * 100) : 0;
    return `<div class="bar-row">
      <span>${p}</span>
      <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
      <span class="bar-count">${c}</span>
    </div>`;
  }).join('');
});