window.Validate = {
  showError(input, message) {
    const group = input.closest('.form-group');
    if (!group) return;
    group.classList.add('has-error');
    const err = group.querySelector('.form-error');
    if (err) err.textContent = message;
  },
  clearError(input) {
    const group = input.closest('.form-group');
    if (group) group.classList.remove('has-error');
  },
  required(form) {
    let ok = true;
    form.querySelectorAll('[required]').forEach(el => {
      this.clearError(el);
      if (!el.value.trim()) {
        this.showError(el, 'This field is required.');
        ok = false;
      }
    });
    return ok;
  },
  email(input) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    this.clearError(input);
    if (!re.test(input.value.trim())) {
      this.showError(input, 'Enter a valid email address.');
      return false;
    }
    return true;
  }
};