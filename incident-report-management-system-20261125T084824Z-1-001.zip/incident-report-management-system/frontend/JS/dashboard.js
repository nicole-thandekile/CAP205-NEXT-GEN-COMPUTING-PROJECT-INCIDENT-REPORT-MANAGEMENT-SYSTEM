document.addEventListener('layout:ready', () => {
  if (!Auth.requireAuth()) return;

  const user = Auth.getUser();
  const greet = document.getElementById('greet');
  if (greet) greet.textContent = `${user.name.split(' ')[0]} 👋`;

  API.getIncidents().then(list => {
    const total = list.length;
    const open = list.filter(i => !['Resolved', 'Closed'].includes(i.status)).length;
    const resolved = list.filter(i => ['Resolved', 'Closed'].includes(i.status)).length;
    const critical = list.filter(i => i.priority === 'Critical').length;

    setText('statTotal', total);
    setText('statOpen', open);
    setText('statResolved', resolved);
    setText('statCritical', critical);

    const tbody = document.getElementById('recentBody');
    if (tbody) {
      tbody.innerHTML = list.slice(0, 5).map(i => `
        <tr>
          <td><a class="incident-link" href="incident-details.html?id=${i.id}">#${i.id}</a></td>
          <td>${Utils.esc(i.title)}</td>
          <td>${Utils.esc(i.category)}</td>
          <td><span class="badge ${Utils.statusClass(i.status)}">${i.status}</span></td>
          <td>${Utils.fmtDate(i.createdAt)}</td>
        </tr>
      `).join('') || `<tr><td colspan="5" class="text-center text-muted">No incidents yet.</td></tr>`;
    }

    const activity = document.getElementById('activityList');
    if (activity) {
      const events = [];
      list.forEach(i => (i.timeline || []).forEach(t => events.push({ ...t, id: i.id })));
      events.sort((a, b) => new Date(b.at) - new Date(a.at));
      activity.innerHTML = events.slice(0, 6).map(e => `
        <li>
          <span>${Utils.esc(e.text)} <a href="incident-details.html?id=${e.id}">#${e.id}</a></span>
          <span class="time">${Utils.fmtDate(e.at)}</span>
        </li>
      `).join('') || '<li class="text-muted">No activity yet.</li>';
    }
  });

  function setText(id, v) {
    const el = document.getElementById(id);
    if (el) el.textContent = v;
  }
});