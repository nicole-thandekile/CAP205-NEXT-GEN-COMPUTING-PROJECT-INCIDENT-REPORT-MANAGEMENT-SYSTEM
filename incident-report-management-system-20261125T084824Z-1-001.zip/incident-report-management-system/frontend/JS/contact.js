// Contact form handling (frontend/contact.html)
document.addEventListener('layout:ready', () => {
  const form = document.getElementById('contactForm');
  if (!form) return;

  // Pre-fill from the logged-in user if available
  const user = Auth.getUser ? Auth.getUser() : null;
  if (user) {
    const nameEl = form.querySelector('[name="fullName"]');
    const emailEl = form.querySelector('[name="email"]');
    if (nameEl && !nameEl.value) nameEl.value = user.name || '';
    if (emailEl && !emailEl.value) emailEl.value = user.email || '';
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!Validate.required(form)) return;
    if (!Validate.email(form.querySelector('[name="email"]'))) return;

    const data = Object.fromEntries(new FormData(form).entries());

    // Store locally (demo) — same approach as API/api.js
    const KEY = 'irms_contact_messages';
    let list = [];
    try { list = JSON.parse(localStorage.getItem(KEY)) || []; } catch { /* ignore */ }
    list.push({ id: Date.now(), ...data, sentAt: new Date().toISOString() });
    localStorage.setItem(KEY, JSON.stringify(list));

    App.showAlert('contactAlert', 'Thank you! Your message has been sent. We will respond shortly.', 'success');
    form.reset();
  });
});