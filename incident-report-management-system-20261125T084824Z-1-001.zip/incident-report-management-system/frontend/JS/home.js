document.addEventListener('DOMContentLoaded', () => {
  const slides = document.querySelectorAll('#heroSlider .slide');
  const dots = document.querySelectorAll('#sliderDots .dot');
  if (!slides.length) return;

  let current = 0;
  let timer;

  function goTo(i) {
    slides[current].classList.remove('active');
    dots[current].classList.remove('active');
    current = i;
    slides[current].classList.add('active');
    dots[current].classList.add('active');
  }

  function next() {
    goTo((current + 1) % slides.length);
  }

  function start() { timer = setInterval(next, 4000); }
  function stop()  { clearInterval(timer); }

  dots.forEach(d => {
    d.addEventListener('click', () => {
      stop();
      goTo(Number(d.dataset.index));
      start();
    });
  });

  start();
});