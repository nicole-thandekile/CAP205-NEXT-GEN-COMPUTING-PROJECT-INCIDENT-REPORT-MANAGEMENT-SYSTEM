window.Auth = {
  KEY: 'irms_user',

  getUser() {
    try { return JSON.parse(localStorage.getItem(this.KEY)); }
    catch { return null; }
  },

  setUser(u) {
    localStorage.setItem(this.KEY, JSON.stringify(u));
  },

  logout() {
    localStorage.removeItem(this.KEY);
    location.href = 'index.html';
  },

  isLoggedIn() { return !!this.getUser(); },

  // Gateway: redirect anonymous users to login, preserving target
  requireAuth(requiredRole) {
    const user = this.getUser();
    if (!user) {
      const back = location.pathname.split('/').pop() + location.search;
      location.href = `login.html?redirect=${encodeURIComponent(back)}`;
      return false;
    }
    if (requiredRole && user.role !== requiredRole) {
      alert('You do not have permission to view this page.');
      location.href = 'dashboard.html';
      return false;
    }
    return true;
  },

  // Called by layout.js after header is injected
  renderAuthState() {
    const box = document.getElementById('navAuth');
    if (!box) return;
    const user = this.getUser();

    if (!user) {
      box.innerHTML = `
        <a href="login.html" class="btn btn-ghost">Login</a>
        <a href="report-incident.html" class="btn btn-primary">Submit Report</a>
      `;
    } else {
      box.innerHTML = `
        <span class="user-chip" title="${Utils.esc(user.email)}">
          <span class="user-avatar">${Utils.initials(user.name)}</span>
          ${Utils.esc(user.name)}
        </span>
        <button class="btn btn-ghost" id="logoutBtn">Logout</button>
      `;
      const btn = document.getElementById('logoutBtn');
      if (btn) btn.addEventListener('click', () => Auth.logout());
    }
  },

  // Handle login form
  login(email, password) {
    const u = MOCK.users.find(x =>
      x.email.toLowerCase() === email.toLowerCase() && x.password === password
    );
    if (!u) return null;
    const safe = { id: u.id, name: u.name, email: u.email, role: u.role, dept: u.dept };
    this.setUser(safe);
    return safe;
  }
};