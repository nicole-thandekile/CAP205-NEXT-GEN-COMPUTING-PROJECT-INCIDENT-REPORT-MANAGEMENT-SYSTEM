document.addEventListener('layout:ready', async () => {
  if (!Auth.requireAuth('admin')) return;

  // Tabs
  document.querySelectorAll('.admin-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.admin-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(tab.dataset.panel).classList.add('active');
    });
  });

  renderUsers();
  renderIncidents();

  document.getElementById('addUserForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const form = e.target;
    if (!Validate.required(form)) return;
    const data = Object.fromEntries(new FormData(form).entries());
    MOCK.users.push({
      id: Math.max(...MOCK.users.map(u => u.id)) + 1,
      ...data
    });
    form.reset();
    renderUsers();
    App.showAlert('adminAlert', 'User added.', 'success');
  });

  function renderUsers() {
    document.getElementById('usersBody').innerHTML = MOCK.users.map(u => `
      <tr>
        <td>#${u.id}</td>
        <td>${Utils.esc(u.name)}</td>
        <td>${Utils.esc(u.email)}</td>
        <td>${Utils.esc(u.dept || '—')}</td>
        <td><span class="badge badge-review">${Utils.esc(u.role)}</span></td>
        <td>
          <button class="btn btn-ghost" data-del="${u.id}">Delete</button>
        </td>
      </tr>
    `).join('');

    document.querySelectorAll('[data-del]').forEach(b => {
      b.addEventListener('click', () => {
        const id = Number(b.dataset.del);
        if (id === Auth.getUser().id) return alert("You can't delete your own account.");
        if (!confirm('Delete this user?')) return;
        const idx = MOCK.users.findIndex(u => u.id === id);
        if (idx > -1) MOCK.users.splice(idx, 1);
        renderUsers();
        App.showAlert('adminAlert', 'User removed.', 'success');
      });
    });
  }

  function renderIncidents() {
    document.getElementById('adminIncidentsBody').innerHTML =
      MOCK.incidents.map(i => `
        <tr>
          <td><a href="incident-details.html?id=${i.id}">#${i.id}</a></td>
          <td>${Utils.esc(i.title)}</td>
          <td>${Utils.esc(i.category)}</td>
          <td><span class="badge ${Utils.statusClass(i.status)}">${i.status}</span></td>
          <td>${Utils.esc(i.reporterName)}</td>
        </tr>
      `).join('');
  }
});