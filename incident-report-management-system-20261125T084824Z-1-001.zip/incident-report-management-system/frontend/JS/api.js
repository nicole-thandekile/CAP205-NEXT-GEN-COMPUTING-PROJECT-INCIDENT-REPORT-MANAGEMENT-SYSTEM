window.API = {
  BASE: 'http://localhost:5000/api',
  KEY: 'irms_incidents',

  _all() {
    const saved = localStorage.getItem(this.KEY);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    localStorage.setItem(this.KEY, JSON.stringify(MOCK.incidents));
    return [...MOCK.incidents];
  },

  _save(list) {
    localStorage.setItem(this.KEY, JSON.stringify(list));
  },

  async getIncidents() {
    return Promise.resolve(this._all());
  },

  async getIncident(id) {
    const i = this._all().find(x => x.id === Number(id));
    return Promise.resolve(i || null);
  },

  async createIncident(data) {
    const user = Auth.getUser();
    const list = this._all();
    const newInc = {
      id: 1000 + list.length + 1,
      ...data,
      status: 'New',
      reporterId: user?.id,
      reporterName: user?.name,
      assignedTo: null,
      assignedName: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      evidence: data.evidence || '',
      timeline: [
        { at: new Date().toISOString(), text: `Report submitted by ${user?.name || 'Guest'}` }
      ]
    };
    list.unshift(newInc);
    this._save(list);
    return Promise.resolve(newInc);
  },

  async updateIncident(id, changes, note) {
    const list = this._all();
    const inc = list.find(x => x.id === Number(id));
    if (!inc) return null;

    const user = Auth.getUser();
    Object.assign(inc, changes, { updatedAt: new Date().toISOString() });

    if (note) {
      inc.timeline = inc.timeline || [];
      inc.timeline.push({ at: new Date().toISOString(), text: note });
    } else if (user) {
      inc.timeline = inc.timeline || [];
      inc.timeline.push({
        at: new Date().toISOString(),
        text: `Updated by ${user.name}`
      });
    }

    this._save(list);
    return Promise.resolve(inc);
  },

  async getUsers() {
    return Promise.resolve([...MOCK.users]);
  }
};