document.addEventListener('layout:ready', async () => {
  if (!Auth.requireAuth()) return;

  const tbody = document.getElementById('incidentsBody');
  if (!tbody) return;

  const user = Auth.getUser();
  const canManage = user.role === 'admin' || user.role === 'officer';

  const searchEl = document.getElementById('searchInput');
  const statusEl = document.getElementById('filterStatus');
  const catEl = document.getElementById('filterCategory');
  const priEl = document.getElementById('filterPriority');

  statusEl.innerHTML = `<option value="">All statuses</option>` +
    MOCK.statuses.map(s => `<option>${s}</option>`).join('');
  catEl.innerHTML = `<option value="">All categories</option>` +
    MOCK.categories.map(c => `<option>${c}</option>`).join('');
  priEl.innerHTML = `<option value="">All priorities</option>` +
    MOCK.priorities.map(p => `<option>${p}</option>`).join('');

  let list = await API.getIncidents();
  render();

  [searchEl, statusEl, catEl, priEl].forEach(el => {
    el.addEventListener('input', render);
  });

  function render() {
    const q = (searchEl.value || '').toLowerCase();
    const filtered = list.filter(i => {
      const matchesQ = !q ||
        i.title.toLowerCase().includes(q) ||
        (i.location || '').toLowerCase().includes(q) ||
        String(i.id).includes(q);
      const matchesS = !statusEl.value || i.status === statusEl.value;
      const matchesC = !catEl.value || i.category === catEl.value;
      const matchesP = !priEl.value || i.priority === priEl.value;
      return matchesQ && matchesS && matchesC && matchesP;
    });

    if (!filtered.length) {
      tbody.innerHTML = `<tr><td colspan="8">
        <div class="empty-state"><div class="icon">🗂️</div>No incidents match your filters.</div>
      </td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(i => {
      const statusCell = canManage
        ? `<select class="form-control status-quick" data-id="${i.id}" style="padding:4px 8px;font-size:.8rem;">
             ${MOCK.statuses.map(s =>
               `<option ${s === i.status ? 'selected' : ''}>${s}</option>`).join('')}
           </select>`
        : `<span class="badge ${Utils.statusClass(i.status)}">${i.status}</span>`;

      return `
        <tr>
          <td><a class="incident-link" href="incident-details.html?id=${i.id}">#${i.id}</a></td>
          <td>${Utils.esc(i.title)}</td>
          <td>${Utils.esc(i.category)}</td>
          <td>${Utils.esc(i.location || '—')}</td>
          <td><span class="badge ${Utils.priorityClass(i.priority)}">${i.priority}</span></td>
          <td>${statusCell}</td>
          <td>${Utils.fmtDate(i.incidentDate)}</td>
          <td>${Utils.esc(i.reporterName)}</td>
        </tr>
      `;
    }).join('');

    // Bind quick status change (admin/officer only)
    if (canManage) {
      tbody.querySelectorAll('.status-quick').forEach(sel => {
        sel.addEventListener('change', async () => {
          const id = Number(sel.dataset.id);
          const newStatus = sel.value;
          const inc = list.find(x => x.id === id);
          const oldStatus = inc.status;
          if (oldStatus === newStatus) return;

          await API.updateIncident(id, { status: newStatus },
            `Status changed: ${oldStatus} → ${newStatus} by ${user.name}`);

          inc.status = newStatus;
          App.showAlert('listAlert', `#${id} status updated to "${newStatus}".`, 'success');
          render();
        });
      });
    }
  }
});