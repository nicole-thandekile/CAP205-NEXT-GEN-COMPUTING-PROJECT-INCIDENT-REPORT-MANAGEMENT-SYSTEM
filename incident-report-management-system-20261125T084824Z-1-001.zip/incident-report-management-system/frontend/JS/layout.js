// Injects shared header + footer, wires modals, then fires 'layout:ready'
(async function () {
  async function loadPartial(path, targetId) {
    const el = document.getElementById(targetId);
    if (!el) return;
    try {
      const res = await fetch(path);
      if (!res.ok) throw new Error(res.statusText);
      el.innerHTML = await res.text();
    } catch (err) {
      console.warn('Could not load', path, err);
    }
  }

  document.addEventListener('DOMContentLoaded', async () => {
    await loadPartial('components/header.html', 'site-header');
    await loadPartial('components/footer.html', 'site-footer');

    // Footer year
    const y = document.getElementById('year');
    if (y) y.textContent = new Date().getFullYear();

    // Mobile menu
    const toggle = document.getElementById('menuToggle');
    const nav = document.getElementById('mainNav');
    if (toggle && nav) {
      toggle.addEventListener('click', () => nav.classList.toggle('open'));
    }

    // Highlight current page
    const here = location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.main-nav a').forEach(a => {
      if (a.getAttribute('href') === here) a.classList.add('active');
    });

    // ===== Modals =====
    function openModal(id) {
      const m = document.getElementById(id);
      if (m) m.classList.add('open');
    }
    function closeModal(el) {
      if (el) el.classList.remove('open');
    }

    document.getElementById('openHelp')?.addEventListener('click', (e) => {
      e.preventDefault(); openModal('helpModal');
    });
    document.getElementById('openFaqs')?.addEventListener('click', (e) => {
      e.preventDefault(); openModal('faqsModal');
    });
    document.getElementById('openFaqsFooter')?.addEventListener('click', (e) => {
      e.preventDefault(); openModal('faqsModal');
    });


    // Close buttons
    document.querySelectorAll('[data-close-modal]').forEach(btn => {
      btn.addEventListener('click', () => closeModal(btn.closest('.modal-overlay')));
    });

    // Click outside to close
    document.querySelectorAll('.modal-overlay').forEach(ov => {
      ov.addEventListener('click', (e) => {
        if (e.target === ov) closeModal(ov);
      });
    });

    // ESC to close
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.open')
          .forEach(m => m.classList.remove('open'));
      }
    });

    // Let auth.js paint user state
    if (window.Auth && Auth.renderAuthState) Auth.renderAuthState();

    // Tell pages they can init
    document.dispatchEvent(new Event('layout:ready'));
  });
})();