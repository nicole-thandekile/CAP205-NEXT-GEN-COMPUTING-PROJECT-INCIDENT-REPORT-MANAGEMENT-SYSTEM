// Temporary data — swap for real API later
window.MOCK = {
  users: [
    { id: 1, name: 'Admin User',      email: 'admin@irms.test',   password: 'admin123',   role: 'admin',    dept: 'Administration' },
    { id: 2, name: 'Officer Sipho',   email: 'officer@irms.test', password: 'officer123', role: 'officer',  dept: 'Safety' },
    { id: 3, name: 'Nicole Moyo',     email: 'user@irms.test',    password: 'user123',    role: 'reporter', dept: 'Computer Applications' },
    { id: 4, name: 'Nyan Tiawon',     email: 'nyan@irms.test',    password: 'nyan123',    role: 'reporter', dept: 'Computer Applications' }
  ],

  categories: [
    'Accident / Injury',
    'Safety Hazard',
    'Security Issue',
    'Property Damage',
    'Misconduct',
    'Equipment Failure',
    'Technical Problem',
    'Other'
  ],

  statuses: ['New', 'Under Review', 'Assigned', 'In Progress', 'Resolved', 'Closed'],
  priorities: ['Low', 'Medium', 'High', 'Critical'],

  incidents: [
    {
      id: 1001,
      title: 'Slippery floor near Block C entrance',
      category: 'Safety Hazard',
      description: 'Water leakage caused a wet floor near the main entrance. Several students nearly slipped.',
      location: 'Block C — Main Entrance',
      incidentDate: '2026-09-10',
      peopleInvolved: 'Facilities staff',
      priority: 'High',
      status: 'Under Review',
      reporterId: 3,
      reporterName: 'Nicole Moyo',
      assignedTo: null,
      assignedName: null,
      createdAt: '2026-09-10T09:15:00',
      updatedAt: '2026-09-11T10:20:00',
      evidence: 'photo-floor.jpg',
      timeline: [
        { at: '2026-09-10T09:15:00', text: 'Report submitted by Nicole Moyo' },
        { at: '2026-09-10T14:00:00', text: 'Status set to Under Review by Admin User' }
      ]
    },
    {
      id: 1002,
      title: 'Broken lab chair in Computer Lab 2',
      category: 'Property Damage',
      description: 'Chair seat cracked. Unsafe to sit on.',
      location: 'Computer Lab 2',
      incidentDate: '2026-09-12',
      peopleInvolved: '',
      priority: 'Medium',
      status: 'Assigned',
      reporterId: 4,
      reporterName: 'Nyan Tiawon',
      assignedTo: 2,
      assignedName: 'Officer Sipho',
      createdAt: '2026-09-12T11:05:00',
      updatedAt: '2026-09-12T15:30:00',
      evidence: '',
      timeline: [
        { at: '2026-09-12T11:05:00', text: 'Report submitted by Nyan Tiawon' },
        { at: '2026-09-12T15:30:00', text: 'Assigned to Officer Sipho' }
      ]
    },
    {
      id: 1003,
      title: 'Unauthorized access to server room',
      category: 'Security Issue',
      description: 'An unknown person was seen entering the server room without a badge.',
      location: 'IT Block — Server Room',
      incidentDate: '2026-09-13',
      peopleInvolved: 'Unidentified male, ~30s',
      priority: 'Critical',
      status: 'In Progress',
      reporterId: 3,
      reporterName: 'Nicole Moyo',
      assignedTo: 2,
      assignedName: 'Officer Sipho',
      createdAt: '2026-09-13T08:40:00',
      updatedAt: '2026-09-13T12:10:00',
      evidence: 'cctv-snapshot.jpg',
      timeline: [
        { at: '2026-09-13T08:40:00', text: 'Report submitted by Nicole Moyo' },
        { at: '2026-09-13T09:00:00', text: 'Marked Critical by Admin User' },
        { at: '2026-09-13T12:10:00', text: 'Investigation started by Officer Sipho' }
      ]
    },
    {
      id: 1004,
      title: 'Projector not working in Lecture Hall 1',
      category: 'Equipment Failure',
      description: 'Projector powers on but shows no signal.',
      location: 'Lecture Hall 1',
      incidentDate: '2026-09-14',
      peopleInvolved: '',
      priority: 'Low',
      status: 'Resolved',
      reporterId: 4,
      reporterName: 'Nyan Tiawon',
      assignedTo: 2,
      assignedName: 'Officer Sipho',
      createdAt: '2026-09-14T07:55:00',
      updatedAt: '2026-09-15T16:00:00',
      evidence: '',
      timeline: [
        { at: '2026-09-14T07:55:00', text: 'Report submitted by Nyan Tiawon' },
        { at: '2026-09-15T16:00:00', text: 'Marked Resolved by Officer Sipho' }
      ]
    },
    {
      id: 1005,
      title: 'Verbal altercation in cafeteria',
      category: 'Misconduct',
      description: 'Two students were involved in a heated argument.',
      location: 'Cafeteria',
      incidentDate: '2026-09-15',
      peopleInvolved: 'Two students',
      priority: 'Medium',
      status: 'Closed',
      reporterId: 3,
      reporterName: 'Nicole Moyo',
      assignedTo: 1,
      assignedName: 'Admin User',
      createdAt: '2026-09-15T13:20:00',
      updatedAt: '2026-09-16T10:00:00',
      evidence: '',
      timeline: [
        { at: '2026-09-15T13:20:00', text: 'Report submitted by Nicole Moyo' },
        { at: '2026-09-16T10:00:00', text: 'Closed by Admin User' }
      ]
    }
  ]
};