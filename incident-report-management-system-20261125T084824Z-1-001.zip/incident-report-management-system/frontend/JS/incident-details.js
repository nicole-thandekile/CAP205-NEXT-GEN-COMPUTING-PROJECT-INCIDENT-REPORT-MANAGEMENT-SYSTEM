document.addEventListener('layout:ready', async () => {
  if (!Auth.requireAuth()) return;

  const id = Utils.qs('id');
  const wrap = document.getElementById('detailWrap');
  if (!wrap) return;

  const inc = await API.getIncident(id);
  if (!inc) {
    wrap.innerHTML = `<div class="card"><h2>Incident not found</h2>
      <p class="text-muted mt-2">The requested report does not exist.</p>
      <a href="incidents.html" class="btn btn-primary mt-3">Back to Incidents</a></div>`;
    return;
  }

  const user = Auth.getUser();
  const canManage = user.role === 'admin' || user.role === 'officer';

  document.getElementById('incTitle').textContent = `#${inc.id} · ${inc.title}`;
  document.getElementById('incBadges').innerHTML = `
    <span class="badge ${Utils.statusClass(inc.status)}">${inc.status}</span>
    <span class="badge ${Utils.priorityClass(inc.priority)}">${inc.priority}</span>
  `;

  document.getElementById('incBody').innerHTML = `
    <div class="detail-row"><span class="detail-label">Category</span><span>${Utils.esc(inc.category)}</span></div>
    <div class="detail-row"><span class="detail-label">Description</span><span>${Utils.esc(inc.description)}</span></div>
    <div class="detail-row"><span class="detail-label">Location</span><span>${Utils.esc(inc.location || '—')}</span></div>
    <div class="detail-row"><span class="detail-label">Incident date</span><span>${Utils.fmtDate(inc.incidentDate)}</span></div>
    <div class="detail-row"><span class="detail-label">People involved</span><span>${Utils.esc(inc.peopleInvolved || '—')}</span></div>
    <div class="detail-row"><span class="detail-label">Reported by</span><span>${Utils.esc(inc.reporterName)}</span></div>
    <div class="detail-row"><span class="detail-label">Assigned to</span><span>${Utils.esc(inc.assignedName || 'Unassigned')}</span></div>
    <div class="detail-row"><span class="detail-label">Evidence</span><span>${inc.evidence ? Utils.esc(inc.evidence) : '—'}</span></div>
    <div class="detail-row"><span class="detail-label">Created</span><span>${Utils.fmtDateTime(inc.createdAt)}</span></div>
    <div class="detail-row"><span class="detail-label">Updated</span><span>${Utils.fmtDateTime(inc.updatedAt)}</span></div>
  `;

  renderTimeline();

  function renderTimeline() {
    document.getElementById('incTimeline').innerHTML =
      (inc.timeline || []).map(t => `
        <li>${Utils.esc(t.text)}<br>
          <span class="text-muted" style="font-size:.78rem">${Utils.fmtDateTime(t.at)}</span>
        </li>
      `).join('') || '<li class="text-muted">No history yet.</li>';
  }

  const actionPanel = document.getElementById('actionPanel');
  if (canManage && actionPanel) {
    actionPanel.style.display = 'block';
    actionPanel.innerHTML = `
      <h3 class="section-title">Manage Incident</h3>
      <div class="form-group">
        <label>Status</label>
        <select id="updStatus" class="form-control">
          ${MOCK.statuses.map(s => `<option ${s === inc.status ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Assign to</label>
        <select id="updAssignee" class="form-control">
          <option value="">— Unassigned —</option>
          ${MOCK.users.filter(u => u.role !== 'reporter').map(u =>
            `<option value="${u.id}" ${u.id === inc.assignedTo ? 'selected' : ''}>
              ${Utils.esc(u.name)} (${u.role})
            </option>`
          ).join('')}
        </select>
      </div>
      <button class="btn btn-primary btn-block" id="saveBtn">Save Changes</button>
    `;

    document.getElementById('saveBtn').addEventListener('click', async () => {
      const newStatus = document.getElementById('updStatus').value;
      const newAssigneeId = document.getElementById('updAssignee').value;
      const assignee = newAssigneeId
        ? MOCK.users.find(u => u.id === Number(newAssigneeId))
        : null;

      const before = `${inc.status} / ${inc.assignedName || 'Unassigned'}`;
      const after = `${newStatus} / ${assignee ? assignee.name : 'Unassigned'}`;
      if (before === after) {
        return App.showAlert('detailAlert', 'No changes to save.', 'info');
      }

      await API.updateIncident(inc.id, {
        status: newStatus,
        assignedTo: assignee ? assignee.id : null,
        assignedName: assignee ? assignee.name : null
      }, `Updated: ${before} → ${after} by ${user.name}`);

      App.showAlert('detailAlert', 'Incident updated successfully.', 'success');
      setTimeout(() => location.reload(), 700);
    });
  }
});