document.addEventListener('layout:ready', () => {
  if (!Auth.requireAuth()) return;

  const user = Auth.getUser();
  const wrap = document.getElementById('profileWrap');
  if (!wrap) return;

  wrap.innerHTML = `
    <div class="card">
      <div class="profile-avatar-lg">${Utils.initials(user.name)}</div>
      <div class="profile-name">${Utils.esc(user.name)}</div>
      <div class="profile-role">${Utils.esc(user.role)}</div>
      <ul class="profile-meta">
        <li><strong>Email:</strong> ${Utils.esc(user.email)}</li>
        <li><strong>Department:</strong> ${Utils.esc(user.dept || '—')}</li>
        <li><strong>User ID:</strong> #${user.id}</li>
      </ul>
    </div>
  `;
});